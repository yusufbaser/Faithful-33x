#version 150

in vec4 Position;

uniform vec4 FogColor;

void main() {
    int id = gl_VertexID;
	
	bool isSky = abs(Position.y - 16.0) < 0.004 && (length(Position.xz) <= 0.004 || abs(length(Position.xz) - 512.0) < 0.004);
	
    if (!isSky) {
        gl_Position = vec4(-1.0);
        return;
    }
    switch(id) {
        case 0:
            gl_Position = vec4(-2.0, 10.0, 0.0, 1.0);
            break;
        case 1:
            gl_Position = vec4(-2.0, -2.0, 0.0, 1.0);
            break;
        case 2:
            gl_Position = vec4(10.0, -2.0, 0.0, 1.0);
            break;
        default:
            gl_Position = vec4(10.0, 10.0, 0.0, 1.0);
            break;
    }
}
